// Recuperar as informações do usuário no localStorage
const user = JSON.parse(localStorage.getItem('user'));
const userId = user.id;  // Id do usuário, pode ser útil para o backend

// Mostrar as informações no dashboard
document.getElementById('peso').textContent = user.peso;  // Peso do usuário
document.getElementById('meta').textContent = user.meta;  // Meta de saúde definida pelo usuário

// Função para calcular IMC
const calcularIMC = (peso, altura) => {
    return peso / (altura * altura);
};

// Calcular e exibir o IMC
const imc = calcularIMC(user.peso, user.altura);
document.getElementById('imc').textContent = imc.toFixed(2);

// Notificações de metas de saúde
const notifications = [
    { message: "Lembre-se de registrar seu peso para acompanhar sua evolução!", type: "reminder" },
    { message: "Você atingiu sua meta de peso! Parabéns!", type: "conquest" }
];

const notificationsList = document.getElementById('notifications-list');
notifications.forEach(notification => {
    const listItem = document.createElement('li');
    listItem.textContent = notification.message;
    listItem.classList.add(notification.type);
    notificationsList.appendChild(listItem);
});

// Navegação para o perfil
document.getElementById('perfil-btn').addEventListener('click', () => {
    window.location.href = 'perfil.html';  // Redireciona para a página do perfil do usuário
});

// Logout
document.getElementById('logout-btn').addEventListener('click', () => {
    localStorage.removeItem('user');  // Remove o usuário do localStorage
    window.location.href = 'login.html';  // Redireciona para a página de login
});
